use northwind
show collections
print("categories")
db.categories.count()
print("customers")
db.customers.count()
print("employees")
db.employees.count()
print("employeeterritories")
db.employeeterritories.count()
print("orderdetails")
db.orderdetails.count()
print("orders")
db.orders.count()
print("products")
db.products.count()
print("regions")
db.regions.count()
print("shippers")
db.shippers.count()
print("suppliers")
db.suppliers.count()
print("territories")
db.territories.count()






